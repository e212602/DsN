#!/usr/bin/python3
import threading
import sys
import os
import signal
from datetime import datetime
import argparse
from enum import Enum
import networkx as nx
import matplotlib.pyplot as plt
import time
from Topology import Topology
from  utils import *
from Messages import *
from cryptography.hazmat.primitives.ciphers import (
    Cipher, algorithms, modes
)



__version__ = "Demo"



if __name__ == "__main__":
    try:
        #G = nx.random_geometric_graph(10,0.5)
        #nx.draw(G, with_labels=True, font_weight='bold')
        #plt.draw()
        #topo = Topology(G)
        
        #root = topo.GetRoot()
        #for i in topo.GetRoot().GetNeighbours():
        #    msg = root.CreateMsg(i,Protocol.TEST,"Hi")
        #    root.Sendmsg(msg)
            
        #plt.show()
        m = hashlib.sha256()
        m.update(b"Nobody inspects")
        m.update(b" the spammish repetition")
        m.digest()

    except Exception as e:
        print(e)
