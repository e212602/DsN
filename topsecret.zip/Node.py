from threading import Thread, Lock
import queue 
from enum import Enum
from Messages import *
import hashlib

class Node:
    def __init__(self,id):
        self.id = id
        self._neighbours = {}
        self.eventhandlers = {Protocol.TEST: self.TestHandler}
        self.inputqueue = queue.Queue()
        th = Thread(target=self.queue_handler, args=[self.inputqueue])
        th.daemon = True
        th.start()


    def GetNeighbours(self):
        return self._neighbours.values()

    def addNeighbour(self,n):
        self._neighbours[n.id] = n

    def queue_handler(self, myqueue):
        while True:
          msg = myqueue.get()
          if msg.Hdr.Pro in self.eventhandlers:
            self.eventhandlers[msg.Hdr.Pro](msg=msg)  # call the handler
          else:
            print(f"Event Handler: {msg.Hdr.Protocol} is not implemented")
          myqueue.task_done()

    def TestHandler(self, msg: Message):
        print(f"{msg.Hdr.Src} says {msg.payload} to {self.id}")
        pass

    def PutMsg(self,msg:Message):
        self.inputqueue.put_nowait(msg)

    def CreateMsg(self,Dist,Protocol,payload):
        msg = Message(
            Hdr = Header(Src = self.id,
                         Dist = Dist.id,
                         Pro = Protocol ),
            payload = payload
        )
        return msg

    def Sendmsg(self,msg:Message):
        if msg.Hdr.Dist in self._neighbours.keys():
            self._neighbours[msg.Hdr.Dist].PutMsg(msg)
        else:
            print(f"No channel found with {msg.Hdr.Dist}")

    

